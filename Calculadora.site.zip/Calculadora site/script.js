const calcular = () => {
    let display = document.querySelector(".display");
    let buttons = document.querySelectorAll(".btn");
    let limpar = document.querySelector(".limpar");
    let igual = document.querySelector(".igual");

    buttons.forEach((button) => {
        button.addEventListener("click", (e) => {
            let value = e.target.dataset.num;
            display.value += value;
            console.log(e.target.dataset.num);
        });
    });

    igual.addEventListener("click", function () {
        let answer = eval(display.value);
        display.value = answer;
    });

    limpar.addEventListener("click", (e) => {
        display.value = "";
    });
};

calcular();
