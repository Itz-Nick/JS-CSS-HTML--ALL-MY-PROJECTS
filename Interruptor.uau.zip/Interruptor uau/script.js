function toggleLamp() {
    const lampada = document.getElementById('lampada');
    const fundo = document.getElementById('fundo');
    fundo.classList.toggle('desligado');
    lampada.classList.toggle('desligado');
}